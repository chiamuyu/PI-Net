# Copyright (c) 2019, NVIDIA CORPORATION. All rights reserved.
#
# This work is licensed under the Creative Commons Attribution-NonCommercial
# 4.0 International License. To view a copy of this license, visit
# http://creativecommons.org/licenses/by-nc/4.0/ or send a letter to
# Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.

"""Loss functions."""

import tensorflow as tf
import dnnlib.tflib as tflib
from dnnlib.tflib.autosummary import autosummary
import numpy as np
import math
from metric_loss_ops import *

#----------------------------------------------------------------------------
# Convenience func that casts all of its arguments to tf.float32.

def fp32(*values):
    if len(values) == 1 and isinstance(values[0], tuple):
        values = values[0]
    values = tuple(tf.cast(v, tf.float32) for v in values)
    return values if len(values) >= 2 else values[0]

def Mapping_loss(M, reM, D, G, reals, real_label, feature_scale=0.00005, D_scale=0.05,use_pixel=True):
    latent_p, _ = M.get_output_for(reals, phase=True)
    latent_p_n = latent_p* tf.rsqrt(tf.reduce_sum(tf.square(latent_p), axis=1, keepdims=True) + 1e-8)
    #latent_p = tf.nn.l2_normalize( latent_p, dim=1)
    label_num = tf.reduce_sum(
        tf.cast(tf.reverse(tensor=real_label, axis=[1]), dtype=tf.int64)
        * 2 ** tf.range(tf.cast(2, dtype=tf.int64)),axis=1)
    fake_w = reM.get_output_for(latent_p, phase=True)
    recon_loss = tf.reduce_mean(tf.square(fake_w - reals))
    triplet_loss = tf.contrib.losses.metric_learning.triplet_semihard_loss(label_num, latent_p_n)
    return triplet_loss , triplet_loss, recon_loss

def kl(x, y):
    X = tf.distributions.Categorical(logits=x)
    Y = tf.distributions.Categorical(logits=y)
    return tf.distributions.kl_divergence(X, Y)

def Mapping_loss_kl(M, reM, D, G, reals, real_label, loc, feature_scale=0.00005, D_scale=0.05,use_pixel=True):
    KL_loss = []
    latent_p, _ = M.get_output_for(reals, phase=True)
    latent_p_n = latent_p* tf.rsqrt(tf.reduce_sum(tf.square(latent_p), axis=1, keepdims=True) + 1e-8)

    for i in range(len(loc)):
        random = tf.random.normal([8,512],mean = loc[i],stddev=0.02)
        KL_loss.append(kl(latent_p_n[i*8:(i+1)*8],random))
    loss = tf.reduce_mean(KL_loss)
    fake_w = reM.get_output_for(latent_p, phase=True)
    recon_loss = tf.reduce_mean(tf.square(fake_w - reals))
    return loss + recon_loss, recon_loss, loss
    
def reMapping_loss(model, M, reM, D, G, C, reals, real_label, minibatch_size, feature_scale=0.00005, D_scale=0.05,use_pixel=True):
       
    num_layers = G.components.synthesis.input_shape[1]
    mean, predict_w = M.get_output_for(reals, phase=True) #32*512
    #random_ = tf.random.normal([minibatch_size,512],stddev=1.0)
    latent_p = mean #+ sigma*random_

    latent_p_n = latent_p* tf.rsqrt(tf.reduce_sum(tf.square(latent_p), axis=1, keepdims=True) + 1e-8)
    random = tf.random.normal([minibatch_size,512],stddev=0.8)
    #random = random* tf.rsqrt(tf.reduce_sum(tf.square(random), axis=1, keepdims=True) + 1e-8)

    latent_p_noise = latent_p_n + 0.3*random
    fake_w_n, _ = reM.get_output_for(latent_p_noise, phase=True) #32*18*512
    _, predict_fake_w_n = M.get_output_for(fake_w_n, phase=True) #32*512
    
    fake_w, _ = reM.get_output_for(latent_p_n, phase=True) #32*18*512
    _, predict_fake_w = M.get_output_for(fake_w, phase=True) #32*512
    
    recon_loss = tf.reduce_mean(tf.square(fake_w - reals))

    '''
    fake_X = G.get_output_for(fake_w, None, randomize_noise=False)
    vgg16_input_fake = tf.transpose(fake_X, perm=[0, 2, 3, 1])
    vgg16_input_fake = ((vgg16_input_fake + 1) / 2) * 255
    pred = model(vgg16_input_fake)
    
    pre1 = tf.slice(pred,[0,28],[minibatch_size,1])
    pre2 = tf.slice(pred,[0,36],[minibatch_size,1])
    pre_label = tf.concat([pre1,pre2],1)
    label_num2 = tf.reduce_sum(
        tf.cast(tf.reverse(tensor=pre_label, axis=[1]), dtype=tf.int64)
        * 2 ** tf.range(tf.cast(2, dtype=tf.int64)),axis=1)
    
    one_hot_label2 = tf.one_hot(label_num2,4) '''
    
    label_num = tf.reduce_sum(
        tf.cast(tf.reverse(tensor=real_label, axis=[1]), dtype=tf.int64)
        * 2 ** tf.range(tf.cast(4, dtype=tf.int64)),axis=1)
    
    one_hot_label = tf.one_hot(label_num,16) 
    c_loss = tf.reduce_mean(-tf.reduce_sum(one_hot_label * tf.log(predict_w),reduction_indices=[1]))    
    c_loss2 = tf.reduce_mean(-tf.reduce_sum(one_hot_label * tf.log(predict_fake_w),reduction_indices=[1]))    
    #c_loss3 = tf.reduce_mean(-tf.reduce_sum(one_hot_label * tf.log(predict_fake_w_n),reduction_indices=[1]))    

    #c_loss2 = tf.reduce_mean(-tf.reduce_sum(one_hot_label * tf.log(one_hot_label2),reduction_indices=[1]))    

    triplet_loss = tf.contrib.losses.metric_learning.triplet_semihard_loss(label_num, latent_p_n, margin=1.0)
         
    return  recon_loss + c_loss+ c_loss2 +triplet_loss, recon_loss, c_loss2,  recon_loss + c_loss2 #+ triplet_loss#+ adv_loss

def D_loss2(M, reM, D, G, C, reals, real_label,feature_scale=0.00005, D_scale=0.05,use_pixel=True):
    latent_p, _ = M.get_output_for(reals, phase=True)
    fake_w = reM.get_output_for(latent_p, phase=True)
    fake_X = G.components.synthesis.get_output_for(fake_w, randomize_noise=False)
    score_f = C.get_output_for(fake_X, None) 
    Real_I = G.components.synthesis.get_output_for(reals, randomize_noise=False)
    fake_scores_out = fp32(score_f)
    score_r = C.get_output_for(Real_I, None) 
    real_scores_out = fp32(score_r)
    loss_fake = tf.reduce_mean(tf.nn.softplus(fake_scores_out))
    loss_real = tf.reduce_mean(tf.nn.softplus(-real_scores_out))
    return loss_fake + loss_real

def D_loss(M, reM, D, G, C, reals, real_label,feature_scale=0.00005, D_scale=0.05,use_pixel=True):
    latent_p, _ = M.get_output_for(reals, phase=True)
    fake_w = reM.get_output_for(latent_p, phase=True)
    score_f, C_f = D.get_output_for(fake_w, phase=True) 
    fake_scores_out = fp32(score_f)
    score_r, C_r = D.get_output_for(reals, phase=True) 
    real_scores_out = fp32(score_r)
    loss_fake = tf.reduce_mean(tf.nn.softplus(fake_scores_out))
    loss_real = tf.reduce_mean(tf.nn.softplus(-real_scores_out))
    return loss_fake + loss_real
    
def E2_perceptual_loss(E, De, G, C, facenet_model, perceptual_model, minibatch_size, reals, real_label, feature_scale=0.00005, D_scale=0.05, use_pixel=True):
    num_layers = G.components.synthesis.input_shape[1]
    latent_p = E.get_output_for(reals, phase=True)
    #with tf.name_scope('GP_Penalty'):
    #    real_grads = tf.gradients(latent_p, [reals])[0]
    #    r1_penalty = tf.reduce_mean(tf.square(real_grads))
    #    r1_penalty = autosummary('Loss/r1_penalty', r1_penalty)
    #    loss_gp = r1_penalty * 0.5
    latent_p *= tf.rsqrt(tf.reduce_sum(tf.square(latent_p), axis=1, keepdims=True) + 1e-8)
    
    latent_w = De.get_output_for(latent_p, phase=True)
    latent_w = tf.tile(latent_w[:, np.newaxis], [1, num_layers, 1])
    fake_X = G.components.synthesis.get_output_for(latent_w, randomize_noise=False)
    score = C.get_output_for(fake_X, None)     
        
    fake_scores_out = fp32(score)

    with tf.variable_scope('classify3_loss'):
        result = tf.reduce_sum(
            tf.cast(tf.reverse(tensor=real_label, axis=[1]), dtype=tf.int64)
            * 2 ** tf.range(tf.cast(2, dtype=tf.int64)),axis=1)
        triplet_loss = triplet_semihard_loss(result, latent_p)
    with tf.variable_scope('adv_loss'):
        adv_loss = D_scale * tf.reduce_mean(tf.nn.softplus(-fake_scores_out))
        #adv_loss = D_scale * 0.5* tf.reduce_mean((fake_scores_out-1)**2)
        adv_loss = autosummary('Loss/scores/adv_loss', adv_loss)
    
    with tf.variable_scope('perceptual_loss'):
        vgg16_input_real = tf.transpose(reals, perm=[0, 2, 3, 1])
        vgg16_input_real = ((vgg16_input_real + 1) / 2) * 255
        vgg16_input_fake = tf.transpose(fake_X, perm=[0, 2, 3, 1])
        vgg16_input_fake = ((vgg16_input_fake + 1) / 2) * 255
        vgg16_feature_real = perceptual_model(vgg16_input_real)
        vgg16_feature_fake = perceptual_model(vgg16_input_fake)
        recon_loss_feats = feature_scale * tf.reduce_mean(tf.square(vgg16_feature_real - vgg16_feature_fake))
        
        facenet_feature_real = facenet_model(vgg16_input_real)
        facenet_feature_fake = facenet_model(vgg16_input_fake)
        facenet_feature_real *= tf.rsqrt(tf.reduce_sum(tf.square(facenet_feature_real), axis=1, keepdims=True) + 1e-8)
        facenet_feature_fake *= tf.rsqrt(tf.reduce_sum(tf.square(facenet_feature_fake), axis=1, keepdims=True) + 1e-8)
        recon_loss_facenet = feature_scale * tf.reduce_mean(tf.square(facenet_feature_real - facenet_feature_fake))

        if use_pixel:
            recon_loss_pixel = tf.reduce_mean(tf.square(fake_X - reals))
        else:
            recon_loss_pixel = 0
        recon_loss_feats = autosummary('Loss/scores/loss_feats', recon_loss_feats)
        recon_loss_pixel = autosummary('Loss/scores/loss_pixel', recon_loss_pixel)
        recon_loss = recon_loss_pixel + recon_loss_feats + recon_loss_facenet
        recon_loss = autosummary('Loss/scores/recon_loss', recon_loss)
        
    e_loss =  adv_loss  + recon_loss + triplet_loss 

    return e_loss, recon_loss_pixel, recon_loss_feats, triplet_loss

def D_logistic_simplegp(E, De, G, C, reals, real_label, r1_gamma=10.0):

    num_layers = G.components.synthesis.input_shape[1]
    latent_p = E.get_output_for(reals, phase=True)
    latent_p *= tf.rsqrt(tf.reduce_sum(tf.square(latent_p), axis=1, keepdims=True) + 1e-8)
    latent_w = De.get_output_for(latent_p, phase=True)
    
    latent_w = tf.tile(latent_w[:, np.newaxis], [1, num_layers, 1])
    fake_X = G.components.synthesis.get_output_for(latent_w, randomize_noise=False)
        
    score_r = C.get_output_for(reals, None)
    real_scores_out = fp32(score_r)
    score_f = C.get_output_for(fake_X, None)
    fake_scores_out = fp32(score_f)
    
    real_scores_out = autosummary('Loss/scores/real', real_scores_out)
    fake_scores_out = autosummary('Loss/scores/fake', fake_scores_out)
    loss_fake = tf.reduce_mean(tf.nn.softplus(fake_scores_out))
    loss_real = tf.reduce_mean(tf.nn.softplus(-real_scores_out))
    #loss_fake = 0.5* tf.reduce_mean((fake_scores_out)**2)
    #loss_real = 0.5* tf.reduce_mean((real_scores_out-1)**2)
    with tf.name_scope('R1Penalty'):
        real_grads = fp32(tf.gradients(real_scores_out, [reals])[0])
        r1_penalty = tf.reduce_mean(tf.reduce_sum(tf.square(real_grads), axis=[1,2,3]))
        r1_penalty = autosummary('Loss/r1_penalty', r1_penalty)
        loss_gp = r1_penalty * (r1_gamma * 0.5)
        
    loss = loss_fake + loss_real + loss_gp 
    #loss = loss_fake + loss_real 
    return loss, loss_fake, loss_real#, C_scale*c_loss_

#----------------------------------------------------------------------------

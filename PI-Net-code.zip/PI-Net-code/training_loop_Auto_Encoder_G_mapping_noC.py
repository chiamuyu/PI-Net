import tensorflow as tf
import numpy as np
import os
import sys
from utils import imwrite, immerge
import dnnlib
from dnnlib import EasyDict
import dnnlib.tflib as tflib
from training import misc
from perceptual_model import PerceptualModel
import time

import keras
from keras.applications.mobilenet_v2 import MobileNetV2
from keras.models import Model
from keras.models import load_model 
import pandas as pd
from keras.preprocessing.image import ImageDataGenerator, array_to_img, img_to_array, load_img

import collections
from collections import OrderedDict

from os import listdir
from os.path import isfile, isdir, join

from sklearn.utils import shuffle
import csv

from metric_loss_ops import *

dim = 512
def process_reals(x, mirror_augment, drange_data, drange_net):
    with tf.name_scope('ProcessReals'):
        with tf.name_scope('DynamicRange'):
            x = tf.cast(x, tf.float32)
            x = misc.adjust_dynamic_range(x, drange_data, drange_net)
        if mirror_augment:
            with tf.name_scope('MirrorAugment'):
                s = tf.shape(x)
                mask = tf.random_uniform([s[0], 1, 1, 1], 0.0, 1.0)
                mask = tf.tile(mask, [1, s[1], s[2], s[3]])
                x = tf.where(mask < 0.5, x, tf.reverse(x, axis=[3]))
        return x


def parse_tfrecord_tf(record):
    features = tf.parse_single_example(record, features={
        'shape': tf.FixedLenFeature([3], tf.int64),
        'data': tf.FixedLenFeature([], tf.string)})
    data = tf.decode_raw(features['data'], tf.uint8)
    return tf.reshape(data, features['shape'])


def get_train_data(sess, data_dir, submit_config, mode):
    if mode == 'train':
        shuffle = True; repeat = True; batch_size = submit_config.batch_size
    elif mode == 'test':
        shuffle = False; repeat = True; batch_size = submit_config.batch_size_test
    else:
        raise Exception("mode must in ['train', 'test], but got {}" % mode)

    dset = tf.data.TFRecordDataset(data_dir)
    dset = dset.map(parse_tfrecord_tf, num_parallel_calls=16)
    if shuffle:
        bytes_per_item = np.prod([3, submit_config.image_size, submit_config.image_size]) * np.dtype('uint8').itemsize
        dset = dset.shuffle(((4096 << 20) - 1) // bytes_per_item + 1)
    if repeat:
        dset = dset.repeat()
    dset = dset.batch(batch_size)
    train_iterator = tf.data.Iterator.from_structure(dset.output_types, dset.output_shapes)
    training_init_op = train_iterator.make_initializer(dset)
    image_batch = train_iterator.get_next()
    sess.run(training_init_op)
    return image_batch


def test(M, reM, Gs, real_test, submit_config):
    num_layers = Gs.components.synthesis.input_shape[1]
    with tf.name_scope("Run"), tf.control_dependencies(None):
        with tf.device("/cpu:0"):
            in_split = tf.split(real_test, submit_config.num_gpus)
        out_split = []
        out_split_r = []
        num_layers = Gs.components.synthesis.input_shape[1]
        for gpu in range(submit_config.num_gpus):
            with tf.device("/gpu:%d" % gpu):
                mean, sigma = M.get_output_for(real_test, phase=False)
                #random = tf.random.normal([4,512],stddev=1.0)
                p = mean #+ sigma*random
                t_p = p[2:] + tf.random.normal([2,dim],stddev=1.0)
                p = tf.concat([p[:2],t_p], axis=0)
                w, _ = reM.get_output_for(p, phase=False)
                w = tf.tile(w[:, np.newaxis], [1, num_layers, 1])
                fake_X_val = Gs.components.synthesis.get_output_for(w, randomize_noise=False)
                out_split.append(tf.clip_by_value(fake_X_val,-1,1))
                real_test = tf.tile(real_test[:, np.newaxis], [1, num_layers, 1])
                real_X_val = Gs.components.synthesis.get_output_for(real_test, randomize_noise=False)
                out_split_r.append(tf.clip_by_value(real_X_val,-1,1))

        with tf.device("/cpu:0"):
            out_expr = tf.concat(out_split, axis=0)
            out_expr_R = tf.concat(out_split_r, axis=0)
            
    return out_expr, out_expr_R

def get_location(M, reM, Gs, data_w):
    loc = np.zeros((4,512))
    for i in range(len(data_w)):
        for j in range(len(data_w[i])):
            w = data_w[i][j:j+1]
            l, _ = M.run(w, phase=False)
            loc[i] += l[0]
        if len(data_w) !=0:
            loc[i] /= len(data_w)
    return loc
class CelebA():
  '''Wraps the celebA dataset, allowing an easy way to:
       - Select the features of interest,
       - Split the dataset into 'training', 'test' or 'validation' partition.
  '''
  def __init__(self, main_folder='datasets/celeba-128/', selected_features=None, drop_features=[]):
    self.main_folder = main_folder
    test = 'datasets/'
    self.images_folder   = os.path.join(test, 'celeba-128hq/')#img_align_celeba
    self.attributes_path = os.path.join(main_folder, 'list_attr_celeba.csv')
    self.partition_path  = os.path.join(main_folder, 'list_eval_partition.csv')
    self.selected_features = selected_features
    self.features_name = []
    self.__prepare(drop_features)

  def __prepare(self, drop_features):
    '''do some preprocessing before using the data: e.g. feature selection'''
    # attributes:
    if self.selected_features is None:
      self.attributes = pd.read_csv(self.attributes_path)
      self.num_features = 40
    else:
      self.num_features = len(self.selected_features)
      self.selected_features = self.selected_features.copy()
      self.selected_features.append('image_id')
      self.attributes = pd.read_csv(self.attributes_path)[self.selected_features]

    # remove unwanted features:
    for feature in drop_features:
      if feature in self.attributes:
        self.attributes = self.attributes.drop(feature, axis=1)
        self.num_features -= 1
      
    self.attributes.set_index('image_id', inplace=True)
    self.attributes.replace(to_replace=-1, value=0, inplace=True)
    self.attributes['image_id'] = list(self.attributes.index)
  
    self.features_name = list(self.attributes.columns)[:-1]
  
    # load ideal partitioning:
    self.partition = pd.read_csv(self.partition_path)
    self.partition.set_index('image_id', inplace=True)
  
  def split(self, name='training', drop_zero=False):
    '''Returns the ['training', 'validation', 'test'] split of the dataset'''
    # select partition split:
    if name is 'training':
      to_drop = self.partition.where(lambda x: x != 0).dropna()
    elif name is 'validation':
      to_drop = self.partition.where(lambda x: x != 1).dropna()
    elif name is 'test':  # test
      to_drop = self.partition.where(lambda x: x != 2).dropna()
    else:
      raise ValueError('CelebA.split() => `name` must be one of [training, validation, test]')

    partition = self.partition.drop(index=to_drop.index)
      
    # join attributes with selected partition:
    joint = partition.join(self.attributes, how='inner').drop('partition', axis=1)

    if drop_zero is True:
      # select rows with all zeros values
      return joint.loc[(joint[self.features_name] == 1).any(axis=1)]
    elif 0 <= drop_zero <= 1:
      zero = joint.loc[(joint[self.features_name] == 0).all(axis=1)]
      zero = zero.sample(frac=drop_zero)
      return joint.drop(index=zero.index)

    return joint 

class HHFQ():
  '''Wraps the HHFQ dataset, allowing an easy way to:
       - Select the features of interest,
       - Split the dataset into 'training', 'test' or 'validation' partition.
  '''
  def __init__(self, main_folder='datasets/celeba-128/', selected_features=None, drop_features=[]):
    self.main_folder = main_folder
    test = 'datasets/'
    self.images_folder   = os.path.join(test, 'celeba-128hq/')#img_align_celeba
    self.attributes_path = os.path.join(main_folder, 'list_attr_celeba.csv')
    self.partition_path  = os.path.join(main_folder, 'list_eval_partition.csv')
    self.selected_features = selected_features
    self.features_name = []
    self.__prepare(drop_features)

  def __prepare(self, drop_features):
    '''do some preprocessing before using the data: e.g. feature selection'''
    # attributes:
    if self.selected_features is None:
      self.attributes = pd.read_csv(self.attributes_path)
      self.num_features = 4
    else:
      self.num_features = len(self.selected_features)
      self.selected_features = self.selected_features.copy()
      self.selected_features.append('image_id')
      self.attributes = pd.read_csv(self.attributes_path)[self.selected_features]

    # remove unwanted features:
    for feature in drop_features:
      if feature in self.attributes:
        self.attributes = self.attributes.drop(feature, axis=1)
        self.num_features -= 1
      
    self.attributes.set_index('image_id', inplace=True)
    self.attributes.replace(to_replace=-1, value=0, inplace=True)
    self.attributes['image_id'] = list(self.attributes.index)
  
    self.features_name = list(self.attributes.columns)[:-1]
  
    # load ideal partitioning:
    self.partition = pd.read_csv(self.partition_path)
    self.partition.set_index('image_id', inplace=True)

def get_latent_w(train, valid):
    trains_w = []
    trains_label = []
    valids_w = []
    valids_label = []
    mypath = './dlatents_dir2'

    # 取得所有檔案與子目錄名稱
    files = listdir(mypath)
    print(mypath)
    #for image_idx in range(num_images):
    # 以迴圈處理
    for f in files:
        str = mypath + '/'+f
        f_name = f.split('.npy')[0]
        if f_name in train.index:
            trains_w.append(np.load(str)[0])
            trains_label.append(np.array(train.loc[f_name][:2]))
        elif f_name in valid.index:
            valids_w.append(np.load(str)[0])
            valids_label.append(np.array(valid.loc[f_name][:2]))
    #input(trains_w[0].shape)
    return np.array(trains_w), np.array(trains_label), np.array(valids_w), np.array(valids_label)

def get_latent_w_group(train, valid):
    #trains_w_g = [[],[],[],[],[],[],[],[]]
    #trains_label_g = [[],[],[],[],[],[],[],[]]
    #valids_w_g = [[],[],[],[],[],[],[],[]]
    #valids_label_g = [[],[],[],[],[],[],[],[]]
    trains_w_g = [[],[],[],[]]
    trains_label_g = [[],[],[],[]]
    valids_w_g = [[],[],[],[]]
    valids_label_g = [[],[],[],[]]
    count_t = 0
    count_v = 0
    mypath = './dlatents_dir2'

    # 取得所有檔案與子目錄名稱
    files = listdir(mypath)
    print(mypath)
    #for image_idx in range(num_images):
    # 以迴圈處理
    for f in files:
        str = mypath + '/'+f
        f_name = f.split('.npy')[0]
        if f_name in train.index:
            label = np.array(train.loc[f_name][:2])
            #index = label[2] + 2* label[1] + 4* label[0]
            index = 1* label[1] + 2* label[0]
            trains_w_g[index].append(np.load(str)[0])
            trains_label_g[index].append(label)
            count_t+=1
        elif f_name in valid.index:
            label = np.array(valid.loc[f_name][:2])
            #index = label[2] + 2* label[1] + 4* label[0]
            index = 1* label[1] + 2* label[0]
            valids_w_g[index].append(np.load(str)[0])
            valids_label_g[index].append(label)
            count_v+=1
    for i in range(len(valids_w_g)):
        trains_w_g[i] = np.array(trains_w_g[i])
        trains_label_g[i] = np.array(trains_label_g[i])
        valids_w_g[i] = np.array(valids_w_g[i])
        valids_label_g[i] = np.array(valids_label_g[i])
    #input(trains_w[0].shape)
    return count_t, count_v, np.array(trains_w_g), np.array(trains_label_g), np.array(valids_w_g), np.array(valids_label_g)


def label_check(real_label):
    label_num = tf.reduce_sum(
        tf.cast(tf.reverse(tensor=real_label, axis=[1]), dtype=tf.int64)
        * 2 ** tf.range(tf.cast(4, dtype=tf.int64)),axis=1)
    return label_num

def test_valid(reals, real_label, M, reM):
    mean, sigma = M.get_output_for(reals, phase=False)
    random = tf.random.normal([1,dim],stddev=1.0)
    latent_p = mean #+ sigma*random
    latent_p_n = latent_p* tf.rsqrt(tf.reduce_sum(tf.square(latent_p), axis=1, keepdims=True) + 1e-8)
    fake_w,predict_ys = reM.get_output_for(latent_p, phase=False) #32*18*512
    recon_loss = tf.reduce_mean(tf.square(fake_w - reals))
    label_num = tf.reduce_sum(
        tf.cast(tf.reverse(tensor=real_label, axis=[1]), dtype=tf.int64)
        * 2 ** tf.range(tf.cast(4, dtype=tf.int64)),axis=1)
    accuracy = compute_accuracy(label_num, predict_ys)
    triplet_loss = tf.contrib.losses.metric_learning.triplet_semihard_loss(label_num, latent_p_n)
    return recon_loss, triplet_loss, accuracy

def getTrainingData(Gs, batch_size):
    latents = np.random.laplace(scale= 1,size=(batch_size,512))
    w_avg = Gs.get_var('dlatent_avg') # [component]
    truncation_psi = 0.5
    w = Gs.components.mapping.run(latents, None)         
    w = w_avg + (w - w_avg) * truncation_psi
    return w
    
def get_training_data(group):
    print('Getting training data...')
    
    celeba = CelebA(drop_features=[
        'Attractive',
        'Pale_Skin',
        'Blurry',
        '5_o_Clock_Shadow',
         'Arched_Eyebrows',
         'Bags_Under_Eyes',
         'Bald',
         'Bangs',
         'Big_Lips',
         'Big_Nose',
         'Black_Hair',
         'Blond_Hair',
         'Brown_Hair',
         'Bushy_Eyebrows',
         'Chubby',
         'Double_Chin',
         'Eyeglasses',
         'Goatee',
         'Gray_Hair',
         'Heavy_Makeup',
         'High_Cheekbones',
         'Male',
         'Mouth_Slightly_Open',
         'Mustache',
         'Narrow_Eyes',
         #'No_Beard',
         'Oval_Face',
         'Pointy_Nose',
         'Receding_Hairline',
         'Rosy_Cheeks',
         'Sideburns',
         #'Smiling',
         'Straight_Hair',
         'Wavy_Hair',
         'Wearing_Earrings',
         'Wearing_Hat',
         'Wearing_Lipstick',
         'Wearing_Necklace',
         'Wearing_Necktie',
         'Young'
    ])
    
    
    # ------------------------------------------------------------------------------
    # -- Preparing Data Generators for training and validation set
    # ------------------------------------------------------------------------------

    # get training and validation set:
    train_split = celeba.split('training'  , drop_zero=False)
    valid_split = celeba.split('validation', drop_zero=False)
    
    #trains_w, train_label, valid_w, valid_label = get_latent_w(train_split,valid_split)
    if group:
        count_t ,count_v, trains_w, train_label, valid_w, valid_label = get_latent_w_group(train_split,valid_split)
    
        return count_t ,count_v, trains_w, train_label, valid_w, valid_label
    trains_w, train_label, valid_w, valid_label = get_latent_w(train_split,valid_split)
    
    return trains_w, train_label, valid_w, valid_label

def get_training_data_w(group):
    print('Getting training data...')
    
    trains_w = []
    trains_label = []
    mypath = './w_latent2/latent_representations/w_latent_4_shuffle.npy'

    w_latent = np.load(mypath)
    #input(w_latent.shape)
    # 開啟 CSV 檔案
    with open('w_latent2/output_4_shuffle.csv', newline='') as csvfile:

      # 讀取 CSV 檔案內容
      rows = csv.reader(csvfile)

      # 以迴圈輸出每一列
      count = 0
      for row in rows:
        if count!=0:
          trains_label.append(np.array(list(map(round, map(float,row[:len(row)-1])))))
        else:
          count=1
    trains_label = np.array(trains_label)
    #w_latent, trains_label = shuffle(w_latent, trains_label, random_state=0)
    #np.save('./w_latent2/latent_representations/w_latent4_shuffle',w_latent)
    #np.save('./w_latent2/latent_representations/w_label4_shuffle',trains_label)
    return w_latent[:int(len(w_latent)*0.8)], trains_label[:int(len(w_latent)*0.8)], w_latent[int(len(w_latent)*0.8):], trains_label[int(len(w_latent)*0.8):]

def get_training_data_w2(group):
    print('Getting training data...')
    
    trains_w = []
    trains_label = []
    mypath = './w_latent2/latent_representations/w_latent4_shuffle.npy'
    mypath_label = './w_latent2/latent_representations/w_label4_shuffle.npy'
    w_latent = np.load(mypath)
    trains_label = np.load(mypath_label)

    return w_latent[:int(len(w_latent)*0.8)], trains_label[:int(len(w_latent)*0.8)], w_latent[int(len(w_latent)*0.8):], trains_label[int(len(w_latent)*0.8):]
    
def test2(E, De, Gs, real_test, submit_config, mirror_augment, drange_data, drange_net):
    with tf.name_scope("Run"), tf.control_dependencies(None):
        with tf.device("/cpu:0"):
            in_split = tf.split(real_test, submit_config.num_gpus)
        out_split = []
        num_layers = Gs.components.synthesis.input_shape[1]
        for gpu in range(submit_config.num_gpus):
            with tf.device("/gpu:%d" % gpu):
                in_gpu = process_reals(in_split[gpu], mirror_augment, drange_data, drange_net)                
                latent_p = E.get_output_for(in_gpu, phase=False)
                latent_p *= tf.rsqrt(tf.reduce_sum(tf.square(latent_p), axis=1, keepdims=True) + 1e-8)

                latent = De.get_output_for(latent_p, phase=False)
                latent_w = tf.tile(latent[:, np.newaxis], [1, num_layers, 1])
                fake_X_val = Gs.components.synthesis.get_output_for(latent_w, randomize_noise=False)
                #out_split.append(tf.clip_by_value(fake_X_val,-1,1))

        with tf.device("/cpu:0"):
            out_expr = tf.concat(fake_X_val, axis=0)

    return out_expr 
    
def compute_accuracy(true_ys, predict_ys):
 
    correct_prediction = tf.equal(tf.argmax(predict_ys,1), true_ys)
    accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
 
    return accuracy
   
def training_loop(
                  submit_config,
                  Mapping_args            = {},
                  reMapping_args          = {},
                  D_args                  = {},
                  M_opt_args              = {},
                  reM_opt_args            = {},
                  D_opt_args              = {},
                  M_loss_args             = {},
                  M_kl_loss_args          = {},
                  reM_loss_args           = {},
                  D_loss_args             = {},
                  Decoder_args2           = {},
                  Encoder_args2           = {},
                  C_args2                 = {},
                  E_opt_args2             = {},
                  E_loss_args2            = {},
                  D_loss_args2            = {},
                  
                  
                  lr_args                 = EasyDict(),
                  tf_config               = {},
                  dataset_args            = EasyDict(),
                  decoder_pkl             = EasyDict(),
                  drange_data             = [0, 255],
                  drange_net              = [-1,1],    # Dynamic range used when feeding image data to the networks.
                  mirror_augment          = False,
                  resume_run_id           = None,      # Run ID or network pkl to resume training from, None = start from scratch.
                  resume_snapshot         = None,      # Snapshot index to resume training from, None = autodetect.
                  image_snapshot_ticks    = 10,         # How often to export image snapshots?
                  network_snapshot_ticks  = 100,        # How often to export network snapshots?
                  save_tf_graph=True,                 # Include full TensorFlow computation graph in the tfevents file?
                  save_weight_histograms=True,        # Include weight histograms in the tfevents file?
                  max_iters               = 15000000,
                  E_smoothing             = 0.999):
   
    tflib.init_tf(tf_config)
    Test = 1
    if Test == 0:
        group = True
        #submit_config.batch_size = 4
        #input(submit_config.batch_size_test)
        with tf.name_scope('input'):
            real_train = tf.placeholder(tf.float32, [submit_config.batch_size, 3, submit_config.image_size, submit_config.image_size], name='real_image_train')
            real_label_train = tf.placeholder(tf.float32, [submit_config.batch_size, 2], name='real_label_train')
            real_test = tf.placeholder(tf.float32, [submit_config.batch_size_test, 3, submit_config.image_size, submit_config.image_size], name='real_image_test')
            real_label_test = tf.placeholder(tf.float32, [submit_config.batch_size_test, 2], name='real_label_test')
            real_split = tf.split(real_train, num_or_size_splits=submit_config.num_gpus, axis=0)
        
        if resume_run_id is not None:
            network_pkl = misc.locate_network_pkl(resume_run_id, resume_snapshot)

            start = int(network_pkl.split('-')[-1].split('.')[0]) // submit_config.batch_size
            global_step = tf.Variable(start, trainable=False, name='learning_rate_step')
            learning_rate = tf.train.exponential_decay(lr_args.learning_rate, global_step, lr_args.decay_step,
                                           lr_args.decay_rate, staircase=lr_args.stair)
            add_global = global_step.assign_add(1)  
            init_op=tf.global_variables_initializer()
            sess_ = tf.get_default_session()
            sess_.run(init_op)
            
            with tf.device('/gpu:0'):
                #network_pkl = 'network-snapshot-00126416.pkl'
                print('Loading networks from "%s"...' % network_pkl)
                E, De, G, C, Gs = misc.load_pkl(network_pkl)
            
        else:
            print('Constructing networks...')
            print(decoder_pkl.decoder_pkl)
            start = 0
            global_step = tf.Variable(start, trainable=False, name='learning_rate_step')
            learning_rate = tf.train.exponential_decay(lr_args.learning_rate, global_step, lr_args.decay_step,
                                           lr_args.decay_rate, staircase=lr_args.stair)
            add_global = global_step.assign_add(1) 
            init_op=tf.global_variables_initializer()
            sess_ = tf.get_default_session()
            sess_.run(init_op)
            
            with tf.device('/gpu:0'):
                E_, G, C, Gs, NE = misc.load_pkl(decoder_pkl.decoder_pkl)
                #C = tflib.Network('D', num_channels=3, resolution=128, label_size=0, **C_args2)
                #names = [name for name in C.trainables.keys() if name in D_.own_vars]
                #tflib.set_vars(tflib.run({C.vars[name]: D_.vars[name] for name in names}))

                E = tflib.Network('E', size=submit_config.image_size, filter=64, filter_max=1024, phase=True, **Encoder_args2)
                De = tflib.Network('De', size=512, filter=64, filter_max=1024, phase=True, **Decoder_args2)

            
            #start = int(network_pkl.split('-')[-1].split('.')[0]) // submit_config.batch_size

        Gs.print_layers(); E.print_layers(); De.print_layers(); C.print_layers()
        #lrate_in    = tf.placeholder(tf.float32, name='lrate_in', shape=[])
        #global_step = tf.Variable(start, trainable=False, name='learning_rate_step')
        #learning_rate = lrate_in    
     
        
        E_opt = tflib.Optimizer(name='TrainE', learning_rate=learning_rate, **E_opt_args2)
        De_opt = tflib.Optimizer(name='TrainDE', learning_rate=learning_rate, **E_opt_args2)
        D_opt = tflib.Optimizer(name='TrainD', learning_rate=learning_rate, **D_opt_args)

        E_loss_rec = 0.
        E_loss_adv = 0.
        De_loss_rec = 0.
        De_loss_adv = 0.
        D_loss_real = 0.
        D_loss_fake = 0.
        D_loss_grad = 0.
        for gpu in range(submit_config.num_gpus):
            print('build graph on gpu %s' % str(gpu))
            with tf.name_scope('GPU%d' % gpu), tf.device('/gpu:%d' % gpu):
                E_gpu = E if gpu == 0 else E.clone(E.name + '_shadow')
                De_gpu = De if gpu == 0 else De.clone(De.name + '_shadow')
                C_gpu = C if gpu == 0 else C.clone(C.name + '_shadow')
                #D_gpu = D if gpu == 0 else D.clone(D.name + '_shadow')
                G_gpu = Gs if gpu == 0 else Gs.clone(Gs.name + '_shadow')
                perceptual_model = PerceptualModel(img_size=[submit_config.image_size, submit_config.image_size], multi_layers=False)
                real_gpu = process_reals(real_split[gpu], mirror_augment, drange_data, drange_net)
                model_path = './model/keras/model/facenet_keras.h5'
                model = load_model(model_path)
                with tf.name_scope('E_loss'), tf.control_dependencies(None):
                    E_loss, recon_loss1, recon_loss2, triplet_loss_loss = dnnlib.util.call_func_by_name(E=E_gpu, De = De_gpu, G=G_gpu, C= C_gpu, minibatch_size= submit_config.batch_size, facenet_model=model, perceptual_model=perceptual_model, reals=real_gpu, real_label=real_label_train, **E_loss_args2)
                    E_loss_rec += (recon_loss1+recon_loss2)
                    #E_loss_adv += adv_loss            
                with tf.name_scope('D_loss'), tf.control_dependencies(None):
                    D_loss, loss_fake, loss_real = dnnlib.util.call_func_by_name(E=E_gpu, De = De_gpu, G=G_gpu, C= C_gpu, reals=real_gpu, real_label=real_label_train, **D_loss_args2)
                    D_loss_real += loss_real
                    D_loss_fake += loss_fake
                    #D_loss_grad += loss_gp
                with tf.control_dependencies([add_global]):
                    both=OrderedDict( list(E_gpu.trainables.items()) + list(De_gpu.trainables.items()))
                    E_opt.register_gradients(E_loss, both)
                #De_opt.register_gradients(adv_loss, E_gpu.trainables)
                    D_opt.register_gradients(D_loss, C_gpu.trainables)

        E_loss_rec /= submit_config.num_gpus
        E_loss_adv /= submit_config.num_gpus
        De_loss_rec /= submit_config.num_gpus
        De_loss_adv /= submit_config.num_gpus
        D_loss_real /=submit_config.num_gpus
        D_loss_fake /=submit_config.num_gpus
        D_loss_grad /=submit_config.num_gpus
     
        E_train_op = E_opt.apply_updates()
        #De_train_op = De_opt.apply_updates()
        D_train_op = D_opt.apply_updates()

        print('building testing graph...')
        fake_X_val = test2(E, De, Gs, real_test, submit_config, mirror_augment, drange_data, drange_net)
        sess = tf.get_default_session()
        celeba = CelebA(drop_features=[
        'Attractive',
        'Pale_Skin',
        'Blurry',
        '5_o_Clock_Shadow',
         'Arched_Eyebrows',
         'Bags_Under_Eyes',
         'Bald',
         'Bangs',
         'Big_Lips',
         'Big_Nose',
         'Black_Hair',
         'Blond_Hair',
         'Brown_Hair',
         'Bushy_Eyebrows',
         'Chubby',
         'Double_Chin',
         'Eyeglasses',
         'Goatee',
         'Gray_Hair',
         'Heavy_Makeup',
         'High_Cheekbones',
         'Male',
         'Mouth_Slightly_Open',
         'Mustache',
         'Narrow_Eyes',
         'No_Beard',
         'Oval_Face',
         'Pointy_Nose',
         'Receding_Hairline',
         'Rosy_Cheeks',
         'Sideburns',
         #'Smiling',
         'Straight_Hair',
         'Wavy_Hair',
         'Wearing_Earrings',
         'Wearing_Hat',
         #'Wearing_Lipstick',
         'Wearing_Necklace',
         'Wearing_Necktie',
         'Young'
        ])
        img_size = 128 #@param ["192", "224"] {type:"raw", allow-input: true}

        IMG_W = img_size 
        IMG_H = img_size
        IMG_SHAPE = (IMG_H, IMG_W, 3)
        TARGET_SIZE = (IMG_H, IMG_W)
        # data augmentation only for the training istances:
        train_datagen = ImageDataGenerator()

        valid_datagen = ImageDataGenerator()


        # get training and validation set:
        train_split = celeba.split('training'  , drop_zero=False)
        valid_split = celeba.split('validation', drop_zero=False)

        # data generators:
        train_generator = train_datagen.flow_from_dataframe(
            dataframe=train_split,
            directory=celeba.images_folder,
            x_col='image_id',
            y_col=celeba.features_name,
            target_size=TARGET_SIZE,
            batch_size=submit_config.batch_size,
            class_mode='raw'
        )

        valid_generator = valid_datagen.flow_from_dataframe(
            dataframe=valid_split,
            directory=celeba.images_folder,
            x_col='image_id',
            y_col=celeba.features_name,
            target_size=TARGET_SIZE,
            batch_size=submit_config.batch_size_test,
            class_mode='raw'
        )
        summary_log = tf.summary.FileWriter(submit_config.run_dir)
        if save_tf_graph:
            summary_log.add_graph(tf.get_default_graph())
        if save_weight_histograms:
            E.setup_weight_histograms(); De.setup_weight_histograms(); D.setup_weight_histograms()

        cur_nimg = start * submit_config.batch_size
        cur_tick = 0
        tick_start_nimg = cur_nimg
        start_time = time.time()
        
        print('Optimization starts!!!')
        for it in range(start, max_iters):
            #print('it: ',it)
            data_batch,labels_batch = next(train_generator)
            if(data_batch.shape[0]!=submit_config.batch_size):
                data_batch,labels_batch = next(train_generator)
            #input(labels_batch)
            image_batch_train = data_batch.transpose(0,3,1,2)
            #input(image_batch_train.shape)
            #feed_dict = {real_train: image_batch_train, real_label_train:labels_batch, lrate_in:lr_args.learning_rate}#feed_dict = {real_train: sess.run(image_batch_train), real_label_train:l, lrate_in:lr_args.learning_rate}
            feed_dict = {real_train: image_batch_train, real_label_train:labels_batch}#feed_dict = {real_train: sess.run(image_batch_train), real_label_train:l, lrate_in:lr_args.learning_rate}

            #print('load data')
            _,e0,e1,e2, e3 = sess.run([E_train_op, E_loss, recon_loss1, recon_loss2, triplet_loss_loss], feed_dict=feed_dict)
            
            #sess.run([De_train_op], feed_dict=feed_dict)
            #print('E_train_op')
            #if it%2==0:
            sess.run([D_train_op, D_loss_real, D_loss_fake], feed_dict=feed_dict)
            cur_nimg += submit_config.batch_size
            #print('train')
            if it % 100 == 0:
                print("Iter: %06d  kimg: %-8.1f time: %-12s" % (it, cur_nimg/1000, dnnlib.util.format_time(time.time()-start_time)))
                print("E_loss loss: ",str(e0), "E_loss recon_loss all: ",str(e0) ,"pixel loss: ",str(e1), "feature loss: ",str(e2)," , E_loss triplet_loss: ",str(e3))
                sys.stdout.flush()
                tflib.autosummary.save_summaries(summary_log, it)

            if it % 100 == 0:#>= tick_start_nimg + 65000:
                

                if cur_tick % image_snapshot_ticks == 0:
                    #batch_images_test = sess.run(image_batch_test)
                    v_data_batch,v_labels_batch = next(valid_generator)
                    if(v_data_batch.shape[0]!=submit_config.batch_size_test):
                        v_data_batch,v_labels_batch = next(valid_generator)
                    v_data_batch = v_data_batch.transpose((0,3,1,2))
                    #batch_images_test = misc.adjust_dynamic_range(batch_images_test.astype(np.float32), [0, 255], [-1., 1.])
                    #input(v_data_batch[0])
                    samples2 = sess.run(fake_X_val, feed_dict={real_test: v_data_batch})
                    v_data_batch = v_data_batch/255.0*2-1
                    #input(samples2[0])
                    #input(batch_images_test)
                    #input(samples2)
                    samples2 = samples2.transpose(0, 2, 3, 1)
                    batch_images_test = v_data_batch.transpose(0, 2, 3, 1)
                    orin_recon = np.concatenate([batch_images_test, samples2], axis=0)
                    #input(orin_recon)
                    imwrite(immerge(orin_recon, 2, submit_config.batch_size_test), '%s/iter_%08d.png' % (submit_config.run_dir, cur_nimg))

                if cur_tick % network_snapshot_ticks == 0:
                    pkl = os.path.join(submit_config.run_dir, 'network-snapshot-%08d.pkl' % (cur_nimg))
                    misc.save_pkl((E, De, G, C, Gs), pkl)

                cur_tick += 1
                tick_start_nimg = cur_nimg
        misc.save_pkl((E, De, G, C, Gs), os.path.join(submit_config.run_dir, 'network-final.pkl'))
        summary_log.close()
    elif Test == 1:
        group = False
        if group:
            count_t ,count_v, trains_w, train_label, valid_w, valid_label = get_training_data(group)
        else:
            trains_w, train_label, valid_w, valid_label = get_training_data_w(group)
        #input('load data')
        #print(trains_w.shape,train_label.shape)
        #input('get w')
        #submit_config.batch_size = 4
        #input(submit_config.batch_size_test)
        sess = tf.get_default_session()
        with tf.name_scope('input'):
            real_train = tf.placeholder(tf.float32, [submit_config.batch_size, 512], name='real_w_train')
            real_label_train = tf.placeholder(tf.float32, [submit_config.batch_size, 4], name='real_label_train')
            real_test = tf.placeholder(tf.float32, [submit_config.batch_size_test, 512], name='real_w_test')
            real_label_test = tf.placeholder(tf.float32, [submit_config.batch_size_test, 4], name='real_label_test')
            real_split = tf.split(real_train, num_or_size_splits=submit_config.num_gpus, axis=0)
            
        with tf.device('/gpu:0'):
            if resume_run_id is not None:
                network_pkl = misc.locate_network_pkl(resume_run_id, resume_snapshot)
                #network_pkl = 'network-snapshot-00126416.pkl'
                print('Loading networks from "%s"...' % network_pkl)
                M, reM, D, G, C, Gs = misc.load_pkl(network_pkl)
                
                start = int(network_pkl.split('-')[-1].split('.')[0]) // submit_config.batch_size
            else:
                print('Constructing networks...')

                #G, C, Gs = misc.load_pkl(decoder_pkl.decoder_pkl)
                E_, G, C, Gs, NE = misc.load_pkl(decoder_pkl.decoder_pkl)
                M = tflib.Network('M', size=512, filter=64, filter_max=1024, phase=True, **Mapping_args)
                reM = tflib.Network('reM', size=512, filter=64, filter_max=1024, phase=True, **reMapping_args)
                D = tflib.Network('D', size=512, filter=64, filter_max=1024, phase=True, **D_args)

                start = 0
                #start = int(network_pkl.split('-')[-1].split('.')[0]) // submit_config.batch_size

        Gs.print_layers(); M.print_layers(); reM.print_layers(); D.print_layers()
        lrate_in    = tf.placeholder(tf.float32, name='lrate_in', shape=[])
        global_step = tf.Variable(start, trainable=False, name='learning_rate_step')
        learning_rate = lrate_in#lr_args.learning_rate#tf.train.exponential_decay(lr_args.learning_rate, global_step, lr_args.decay_step,
        
        if group:
            loc = get_location(M, reM, Gs, trains_w)

        #     lr_args.decay_rate, staircase=lr_args.stair)
        #add_global = global_step.assign_add(1)
        #learning_rate = lrate_in
        M_opt = tflib.Optimizer(name='TrainM', learning_rate=learning_rate, **M_opt_args)
        M_kl_opt = tflib.Optimizer(name='TrainMkl', learning_rate=learning_rate, **M_opt_args)

        reM_opt = tflib.Optimizer(name='TrainreM', learning_rate=learning_rate, **reM_opt_args)
        D_opt = tflib.Optimizer(name='TrainD', learning_rate=learning_rate, **D_opt_args)

        M_loss_rec = 0.
        M_loss_adv = 0.
        M_kl_loss_rec = 0.
        reM_loss_rec = 0.
        reM_loss_adv = 0.
        D_loss_rec = 0.
        D_loss_adv = 0.
        for gpu in range(submit_config.num_gpus):
            print('build graph on gpu %s' % str(gpu))
            with tf.name_scope('GPU%d' % gpu), tf.device('/gpu:%d' % gpu):
                C_gpu = C if gpu == 0 else C.clone(C.name + '_shadow')
                M_gpu = M if gpu == 0 else M.clone(M.name + '_shadow')
                reM_gpu = reM if gpu == 0 else reM.clone(reM.name + '_shadow')
                D_gpu = D if gpu == 0 else D.clone(D.name + '_shadow')
                G_gpu = Gs if gpu == 0 else Gs.clone(Gs.name + '_shadow')
                perceptual_model = PerceptualModel(img_size=[submit_config.image_size, submit_config.image_size], multi_layers=False)
                model_attribute = keras.models.load_model("./weights/weights-FC37-MobileNetV2-0.92.hdf5")
                real_gpu = real_split[gpu]
                #with tf.name_scope('M_loss'), tf.control_dependencies(None):
                #    M_loss, tr_Mloss, re_Mloss = dnnlib.util.call_func_by_name(M=M_gpu, reM = reM_gpu, D= D_gpu, G=G_gpu, reals=real_gpu, real_label=real_label_train, **M_loss_args)
                #    M_loss_rec += M_loss
                #if group:
                #    with tf.name_scope('M_kl_loss'), tf.control_dependencies(None):
                #        M_kl_loss, M_kl_reconloss, M_kl_klloss = dnnlib.util.call_func_by_name(M=M_gpu, reM = reM_gpu, D= D_gpu, G=G_gpu, reals=real_gpu, real_label=real_label_train, loc=loc, **M_kl_loss_args)
                #        M_kl_loss_rec += M_kl_loss
                with tf.name_scope('reM_loss'), tf.control_dependencies(None):
                    reM_loss, re_reMloss, tr_reMloss, reM_loss2= dnnlib.util.call_func_by_name(model=model_attribute, M=M_gpu, reM = reM_gpu, D= D_gpu, G=G_gpu, C=C_gpu, reals=real_gpu, real_label=real_label_train, minibatch_size= submit_config.batch_size, **reM_loss_args)
                    reM_loss_rec += reM_loss
                #with tf.name_scope('D_loss'), tf.control_dependencies(None):
                #    D_loss = dnnlib.util.call_func_by_name(M=M_gpu, reM = reM_gpu, D= D_gpu, G=G_gpu, C=C_gpu, reals=real_gpu, real_label=real_label_train, **D_loss_args)
                #    D_loss_rec += D_loss
                #with tf.control_dependencies([add_global]):
                w_vars = [var for var in M_gpu.own_vars.keys() if 'weight' in var]
                w_vars = w_vars[:3]
                weights = []
                for i in w_vars:
                    weights.append(M_gpu.vars[i])
                def l2_penalty(ws):
                    sum_ = 0
                    for w in ws:
                        sum_ += tf.reduce_sum(w**2) / 2    
                    return sum_
                loss_penalty = l2_penalty(weights)
                #reM_loss += loss_penalty
                #M_opt.register_gradients(M_loss, M_gpu.trainables)
                both=OrderedDict(list(M_gpu.trainables.items()) + list(reM_gpu.trainables.items()))
                #if group:
                #    M_kl_opt.register_gradients(M_kl_loss, both)
                M_opt.register_gradients(reM_loss, both)
                reM_opt.register_gradients(reM_loss2, reM_gpu.trainables)
                #D_opt.register_gradients(D_loss, D_gpu.trainables)
        #M_loss_rec /= submit_config.num_gpus
        reM_loss_rec /= submit_config.num_gpus
        #D_loss_rec /= submit_config.num_gpus

        M_train_op = M_opt.apply_updates()
        #if group:
        #    M_kl_train_op = M_kl_opt.apply_updates()
        reM_train_op = reM_opt.apply_updates()
        #D_train_op = D_opt.apply_updates()

        loss_re_v, loss_tr_v, accuracy = test_valid(real_train, real_label_train, M, reM)

        print('building testing graph...')
        fake_X_val, real_image = test(M, reM, Gs, real_test, submit_config)
        
        #t_vars = tf.trainable_variables()
        #uninitialized_vars = [var for var in t_vars if 'bn_' in var.name]
        #uninitialized_vars = []
        #for var in tf.global_variables():
        #    try:
        #        sess.run(var)
        #        #print(var)
        #    except tf.errors.FailedPreconditionError:
        #        uninitialized_vars.append(var)
        #        print(var)
        #init_new_vars_op = tf.initialize_variables(uninitialized_vars)
        #sess.run(init_new_vars_op)
        #testA = [var for var in M.trainables.values()]
        #print(testA)
        #init = tf.initialize_variables(testA)
        #sess.run(init)
        l = label_check(real_label_train)
        batch_num = trains_w.shape[0]//submit_config.batch_size
        batch_size = submit_config.batch_size
        '''
        for it in range(batch_num):
            class_count = np.zeros(4)
            labels_batch = train_label[(it%batch_num)*batch_size:(it%batch_num+1)*batch_size]
            result = sess.run(l,{real_label_train:labels_batch})
            for j in result:
                class_count[j] +=1
            input(class_count)
        input('test')
        '''
        summary_log = tf.summary.FileWriter(submit_config.run_dir)
        if save_tf_graph:
            summary_log.add_graph(tf.get_default_graph())
        if save_weight_histograms:
            M.setup_weight_histograms(); reM.setup_weight_histograms(); #D.setup_weight_histograms()

        cur_nimg = start * submit_config.batch_size
        cur_tick = 0
        tick_start_nimg = cur_nimg
        start_time = time.time()
        
        print('Optimization starts!!!')
        count_v = 0
        if group:
            batch_num = count_t//submit_config.batch_size
            batch_num_v = count_v//submit_config.batch_size_test
            batch_num_v2 = count_v//submit_config.batch_size
        else:
            batch_num = len(trains_w)//submit_config.batch_size
            batch_num_v = len(valid_w)//submit_config.batch_size_test
            batch_num_v2 = len(valid_w)//submit_config.batch_size
        batch_size = submit_config.batch_size
        m_kl_kl_loss = m_kl_re_loss = tr_re_loss = m_loss = tr_m_loss = re_m_loss = re_re_loss = adv_re_loss = rem_loss = d_loss = 0
        #input(batch_num)
        for it in range(start, max_iters):
            if group:
                for i in range(len(trains_w)):
                    trains_w[i], train_label[i] = shuffle(trains_w[i], train_label[i], random_state=0)
                    if i!=0:
                        w_batch_train = np.concatenate((w_batch_train,trains_w[i][:batch_size//4]), axis=0)
                        labels_batch = np.concatenate((labels_batch,train_label[i][:batch_size//4]), axis=0)
                    else:
                        w_batch_train = trains_w[i][:batch_size//4]
                        labels_batch = train_label[i][:batch_size//4]
            else:
                if it%batch_num == 0:
                    trains_w, train_label = shuffle(trains_w, train_label, random_state=0)
                w_batch_train = trains_w[(it%batch_num)*batch_size:(it%batch_num+1)*batch_size]
                labels_batch = train_label[(it%batch_num)*batch_size:(it%batch_num+1)*batch_size]

            #input(labels_batch)

            feed_dictM = {real_train: w_batch_train, real_label_train:labels_batch, lrate_in:lr_args.learning_rate}
            #w2 = getTrainingData(Gs, batch_size)
            #feed_dictreM = {real_train: w2, lrate_in:lr_args.learning_rate}
            
            #if it%10==0:M_kl_opt
            #if it%2==1:
            #_ = sess.run([M_train_op], feed_dict=feed_dictM)
            #if it%500>=2:
            #if tr_re_loss <= 1e-8 and it!=0:
            #    _, m_loss, m_kl_re_loss, m_kl_kl_loss = sess.run([M_kl_train_op, M_kl_loss, M_kl_reconloss, M_kl_klloss], feed_dict=feed_dictM)
            #else:
            #if it%2==0:
            _, l_p, rem_loss, re_re_loss, tr_re_loss = sess.run([M_train_op, loss_penalty, reM_loss_rec, re_reMloss, tr_reMloss], feed_dict=feed_dictM)
           
            cur_nimg += submit_config.batch_size
            #input(l_check)
            #print('train')
            if it%100==0:
                print("Iter: %06d  kimg: %-8.1f time: %-12s" % (it, cur_nimg/1000, dnnlib.util.format_time(time.time()-start_time)))
                print("reM_loss: ",str(rem_loss), "loss_penalty: ",str(l_p), "Re_reM_loss: ",str(re_re_loss), "triplet_reM_loss: ",str(tr_re_loss))
                sys.stdout.flush()
                tflib.autosummary.save_summaries(summary_log, it)
                tr_re_loss = m_loss = tr_m_loss = re_m_loss = re_re_loss = adv_re_loss = rem_loss = d_loss = 0
                
            if it % 100 == 0:#>= tick_start_nimg + 65000:
                

                if cur_tick % image_snapshot_ticks == 0:
                    if group:
                        for i in range(len(trains_w)):
                            valid_w[i], valid_label[i] = shuffle(valid_w[i], valid_label[i], random_state=0)
                            if i!=0:
                                v_data_batch2 = np.concatenate((v_data_batch2,valid_w[i][:batch_size//4]), axis=0)
                                v_labels_batch2 = np.concatenate((v_labels_batch2,valid_label[i][:batch_size//4]), axis=0)
                                v_data_batch = np.concatenate((v_data_batch,valid_w[i][:submit_config.batch_size_test//4]), axis=0)
                            else:
                                v_data_batch2 = valid_w[i][:batch_size//4]
                                v_labels_batch2 = valid_label[i][:batch_size//4]
                                v_data_batch = valid_w[i][:submit_config.batch_size_test//4]
                    #input(submit_config.batch_size_test)
                    else:
                        v_data_batch = valid_w[(count_v%batch_num_v)*submit_config.batch_size_test:(count_v%batch_num_v+1)*submit_config.batch_size_test]
                        v_data_batch2 = valid_w[(count_v%batch_num_v2)*submit_config.batch_size:(count_v%batch_num_v2+1)*submit_config.batch_size]
                        v_labels_batch2 = valid_label[(count_v%batch_num_v2)*submit_config.batch_size:(count_v%batch_num_v2+1)*submit_config.batch_size]

                    rem_loss, re2, acu = sess.run([loss_re_v, loss_tr_v, accuracy], feed_dict={real_train: v_data_batch2, real_label_train:v_labels_batch2})
                    print("loss: ",rem_loss," , triplet_loss: ", re2," , accuracy: ", acu)
                    
                    #v_data_batch = valid_w[(count_v%batch_num_v)*submit_config.batch_size_test:(count_v%batch_num_v+1)*submit_config.batch_size_test]

                    count_v+=1
                    samples2, r_img= sess.run([fake_X_val,real_image], feed_dict={real_test: v_data_batch})

                    samples2 = samples2.transpose(0, 2, 3, 1)
                    batch_images_test = r_img.transpose(0, 2, 3, 1)
                    orin_recon = np.concatenate([batch_images_test, samples2], axis=0)
                    imwrite(immerge(orin_recon, 2, submit_config.batch_size_test), '%s/iter_%08d.png' % (submit_config.run_dir, cur_nimg))

                if cur_tick % network_snapshot_ticks == 0:
                    pkl = os.path.join(submit_config.run_dir, 'network-snapshot-%08d.pkl' % (cur_nimg))
                    misc.save_pkl((M, reM, D, G, C, Gs), pkl)

                cur_tick += 1
                tick_start_nimg = cur_nimg
        misc.save_pkl((M, reM, D, G, C, Gs), os.path.join(submit_config.run_dir, 'network-final.pkl'))
        summary_log.close()    
    elif Test == 2:
        group = True
        if group:
            count_t ,count_v, trains_w, train_label, valid_w, valid_label = get_training_data(group)
        else:
            trains_w, train_label, valid_w, valid_label = get_training_data(group)
        #submit_config.batch_size = 4
        #input(submit_config.batch_size_test)
        with tf.name_scope('input'):
            real_train = tf.placeholder(tf.float32, [submit_config.batch_size, 12, 512], name='real_w_train')
            real_label_train = tf.placeholder(tf.float32, [submit_config.batch_size, 2], name='real_label_train')
            real_test = tf.placeholder(tf.float32, [submit_config.batch_size_test, 12, 512], name='real_w_test')
            real_label_test = tf.placeholder(tf.float32, [submit_config.batch_size_test, 2], name='real_label_test')
            real_split = tf.split(real_train, num_or_size_splits=submit_config.num_gpus, axis=0)
            
        with tf.device('/gpu:0'):
            if resume_run_id is not None:
                network_pkl = misc.locate_network_pkl(resume_run_id, resume_snapshot)
                #network_pkl = 'network-snapshot-00126416.pkl'
                print('Loading networks from "%s"...' % network_pkl)
                M, reM, D, G, C, Gs = misc.load_pkl(network_pkl)
                
                start = int(network_pkl.split('-')[-1].split('.')[0]) // submit_config.batch_size
            else:
                print('Constructing networks...')

                G, C, Gs = misc.load_pkl(decoder_pkl.decoder_pkl)

                M = tflib.Network('M', size=512, filter=64, filter_max=1024, phase=True, **Mapping_args)
                reM = tflib.Network('reM', size=512, filter=64, filter_max=1024, phase=True, **reMapping_args)
                D = tflib.Network('D', size=512, filter=64, filter_max=1024, phase=True, **D_args)
                
                start = 0
                #start = int(network_pkl.split('-')[-1].split('.')[0]) // submit_config.batch_size

        Gs.print_layers(); M.print_layers(); reM.print_layers(); D.print_layers()
        lrate_in    = tf.placeholder(tf.float32, name='lrate_in', shape=[])
        global_step = tf.Variable(start, trainable=False, name='learning_rate_step')
        learning_rate = lrate_in#lr_args.learning_rate#tf.train.exponential_decay(lr_args.learning_rate, global_step, lr_args.decay_step,
        
        if group:
            loc = get_location(M, reM, Gs, trains_w)

        #     lr_args.decay_rate, staircase=lr_args.stair)
        #add_global = global_step.assign_add(1)
        #learning_rate = lrate_in
        M_opt = tflib.Optimizer(name='TrainM', learning_rate=learning_rate, **M_opt_args)
        M_kl_opt = tflib.Optimizer(name='TrainMkl', learning_rate=learning_rate, **M_opt_args)

        reM_opt = tflib.Optimizer(name='TrainreM', learning_rate=learning_rate, **reM_opt_args)
        D_opt = tflib.Optimizer(name='TrainD', learning_rate=learning_rate, **D_opt_args)

        M_loss_rec = 0.
        M_loss_adv = 0.
        M_kl_loss_rec = 0.
        reM_loss_rec = 0.
        reM_loss_adv = 0.
        D_loss_rec = 0.
        D_loss_adv = 0.
        for gpu in range(submit_config.num_gpus):
            print('build graph on gpu %s' % str(gpu))
            with tf.name_scope('GPU%d' % gpu), tf.device('/gpu:%d' % gpu):
                C_gpu = C if gpu == 0 else C.clone(C.name + '_shadow')
                M_gpu = M if gpu == 0 else M.clone(M.name + '_shadow')
                reM_gpu = reM if gpu == 0 else reM.clone(reM.name + '_shadow')
                D_gpu = D if gpu == 0 else D.clone(D.name + '_shadow')
                G_gpu = Gs if gpu == 0 else Gs.clone(Gs.name + '_shadow')
                perceptual_model = PerceptualModel(img_size=[submit_config.image_size, submit_config.image_size], multi_layers=False)
                real_gpu = real_split[gpu]
                with tf.name_scope('M_loss'), tf.control_dependencies(None):
                    M_loss, tr_Mloss, re_Mloss = dnnlib.util.call_func_by_name(M=M_gpu, reM = reM_gpu, D= D_gpu, G=G_gpu, reals=real_gpu, real_label=real_label_train, **M_loss_args)
                    M_loss_rec += M_loss
                if group:
                    with tf.name_scope('M_kl_loss'), tf.control_dependencies(None):
                        M_kl_loss, M_kl_reconloss, M_kl_klloss = dnnlib.util.call_func_by_name(M=M_gpu, reM = reM_gpu, D= D_gpu, G=G_gpu, reals=real_gpu, real_label=real_label_train, loc=loc, **M_kl_loss_args)
                        M_kl_loss_rec += M_kl_loss
                with tf.name_scope('reM_loss'), tf.control_dependencies(None):
                    reM_loss, re_reMloss, adv_reMloss, tr_reMloss= dnnlib.util.call_func_by_name(M=M_gpu, reM = reM_gpu, D= D_gpu, G=G_gpu, C=C_gpu, reals=real_gpu, real_label=real_label_train, minibatch_size= submit_config.batch_size, **reM_loss_args)
                    reM_loss_rec += reM_loss
                with tf.name_scope('D_loss'), tf.control_dependencies(None):
                    D_loss = dnnlib.util.call_func_by_name(M=M_gpu, reM = reM_gpu, D= D_gpu, G=G_gpu, C=C_gpu, reals=real_gpu, real_label=real_label_train, **D_loss_args)
                    D_loss_rec += D_loss
                #with tf.control_dependencies([add_global]):
                M_opt.register_gradients(M_loss, M_gpu.trainables)
                both=OrderedDict(list(M_gpu.trainables.items()) + list(reM_gpu.trainables.items()))
                if group:
                    M_kl_opt.register_gradients(M_kl_loss, both)
                reM_opt.register_gradients(reM_loss, both)
                D_opt.register_gradients(D_loss, D_gpu.trainables)
        M_loss_rec /= submit_config.num_gpus
        reM_loss_rec /= submit_config.num_gpus
        D_loss_rec /= submit_config.num_gpus

        M_train_op = M_opt.apply_updates()
        if group:
            M_kl_train_op = M_kl_opt.apply_updates()
        reM_train_op = reM_opt.apply_updates()
        D_train_op = D_opt.apply_updates()

        loss_re_v, loss_tr_v = test_valid(real_train, real_label_train, M, reM)

        print('building testing graph...')
        fake_X_val, real_image = test(M, reM, Gs, real_test, submit_config)

        sess = tf.get_default_session()


        
        #print(train_label)
        l = label_check(real_label_train)
        batch_num = trains_w.shape[0]//submit_config.batch_size
        batch_size = submit_config.batch_size
        '''
        for it in range(batch_num):
            class_count = np.zeros(4)
            labels_batch = train_label[(it%batch_num)*batch_size:(it%batch_num+1)*batch_size]
            result = sess.run(l,{real_label_train:labels_batch})
            for j in result:
                class_count[j] +=1
            input(class_count)
        input('test')
        '''
        summary_log = tf.summary.FileWriter(submit_config.run_dir)
        if save_tf_graph:
            summary_log.add_graph(tf.get_default_graph())
        if save_weight_histograms:
            M.setup_weight_histograms(); reM.setup_weight_histograms(); D.setup_weight_histograms()

        cur_nimg = start * submit_config.batch_size
        cur_tick = 0
        tick_start_nimg = cur_nimg
        start_time = time.time()
        
        print('Optimization starts!!!')
        count_v = 0
        if group:
            batch_num = count_t//submit_config.batch_size
            batch_num_v = count_v//submit_config.batch_size_test
            batch_num_v2 = count_v//submit_config.batch_size
        else:
            batch_num = len(trains_w)//submit_config.batch_size
            batch_num_v = len(valid_w)//submit_config.batch_size_test
            batch_num_v2 = len(valid_w)//submit_config.batch_size
        batch_size = submit_config.batch_size
        m_kl_kl_loss = m_kl_re_loss = tr_re_loss = m_loss = tr_m_loss = re_m_loss = re_re_loss = adv_re_loss = rem_loss = d_loss = 0
        #input(batch_num)
        for it in range(start, max_iters):
            if group:
                for i in range(len(trains_w)):
                    trains_w[i], train_label[i] = shuffle(trains_w[i], train_label[i], random_state=0)
                    if i!=0:
                        w_batch_train = np.concatenate((w_batch_train,trains_w[i][:batch_size//4]), axis=0)
                        labels_batch = np.concatenate((labels_batch,train_label[i][:batch_size//4]), axis=0)
                    else:
                        w_batch_train = trains_w[i][:batch_size//4]
                        labels_batch = train_label[i][:batch_size//4]
            else:
                if it%batch_num == 0:
                    trains_w, train_label = shuffle(trains_w, train_label, random_state=0)
                w_batch_train = trains_w[(it%batch_num)*batch_size:(it%batch_num+1)*batch_size]
                labels_batch = train_label[(it%batch_num)*batch_size:(it%batch_num+1)*batch_size]

            #input(labels_batch)

            feed_dictM = {real_train: w_batch_train, real_label_train:labels_batch, lrate_in:lr_args.learning_rate}
            #w2 = getTrainingData(Gs, batch_size)
            #feed_dictreM = {real_train: w2, lrate_in:lr_args.learning_rate}
            
            #if it%10==0:M_kl_opt
            _, m_loss, tr_m_loss, re_m_loss = sess.run([M_train_op, M_loss_rec, tr_Mloss, re_Mloss], feed_dict=feed_dictM)
            #if it%500>=2:
            #if tr_re_loss <= 1e-8 and it!=0:
            #    _, m_loss, m_kl_re_loss, m_kl_kl_loss = sess.run([M_kl_train_op, M_kl_loss, M_kl_reconloss, M_kl_klloss], feed_dict=feed_dictM)
            #else:
            _, rem_loss, re_re_loss, adv_re_loss, tr_re_loss = sess.run([reM_train_op, reM_loss_rec, re_reMloss, adv_reMloss, tr_reMloss], feed_dict=feed_dictM)
            #if it%2==0:
            _, d_loss = sess.run([D_train_op, D_loss_rec], feed_dict=feed_dictM)        
            #m_loss += m_loss_
            #tr_m_loss += tr_m_loss_
            #re_m_loss += re_m_loss_
            #rem_loss += rem_loss_
            #re_re_loss += re_re_loss_
            #adv_re_loss += adv_re_loss_
            #tr_re_loss += tr_re_loss_
            #d_loss += d_loss_
            cur_nimg += submit_config.batch_size
            #input(l_check)
            #print('train')
            if it%100==0:
                print("Iter: %06d  kimg: %-8.1f time: %-12s" % (it, cur_nimg/1000, dnnlib.util.format_time(time.time()-start_time)))
                #print("M_loss: ",str(m_loss), "M_loss RECON: ",str(re_m_loss), "M_loss TREIPLET: ",str(tr_m_loss))
                print("M KL_loss: ",str(m_loss),"M KL_reconloss: ",str(m_kl_re_loss),"M KL_klloss: ",str(m_kl_kl_loss),"reM_loss: ",str(rem_loss), "Re_reM_loss: ",str(re_re_loss), "triplet_reM_loss: ",str(tr_re_loss), "adv_reM_loss: ",str(adv_re_loss), "D_loss: ",str(d_loss))
                sys.stdout.flush()
                tflib.autosummary.save_summaries(summary_log, it)
                tr_re_loss = m_loss = tr_m_loss = re_m_loss = re_re_loss = adv_re_loss = rem_loss = d_loss = 0
                
            if it % 100 == 0:#>= tick_start_nimg + 65000:
                

                if cur_tick % image_snapshot_ticks == 0:
                    if group:
                        for i in range(len(trains_w)):
                            valid_w[i], valid_label[i] = shuffle(valid_w[i], valid_label[i], random_state=0)
                            if i!=0:
                                v_data_batch2 = np.concatenate((v_data_batch2,valid_w[i][:batch_size//4]), axis=0)
                                v_labels_batch2 = np.concatenate((v_labels_batch2,valid_label[i][:batch_size//4]), axis=0)
                                v_data_batch = np.concatenate((v_data_batch,valid_w[i][:submit_config.batch_size_test//4]), axis=0)
                            else:
                                v_data_batch2 = valid_w[i][:batch_size//4]
                                v_labels_batch2 = valid_label[i][:batch_size//4]
                                v_data_batch = valid_w[i][:submit_config.batch_size_test//4]
                    #input(submit_config.batch_size_test)
                    else:
                        v_data_batch = trains_w[(it%batch_num_v)*submit_config.batch_size_test:(it%batch_num_v+1)*submit_config.batch_size_test]
                        v_data_batch2 = valid_w[(count_v%batch_num_v2)*submit_config.batch_size:(count_v%batch_num_v2+1)*submit_config.batch_size]
                        v_labels_batch2 = valid_label[(count_v%batch_num_v2)*submit_config.batch_size:(count_v%batch_num_v2+1)*submit_config.batch_size]

                    rem_loss, re2 = sess.run([loss_re_v, loss_tr_v], feed_dict={real_train: v_data_batch2, real_label_train:v_labels_batch2})
                    print("loss: ",rem_loss," , triplet_loss: ", re2)
                    
                    #v_data_batch = valid_w[(count_v%batch_num_v)*submit_config.batch_size_test:(count_v%batch_num_v+1)*submit_config.batch_size_test]

                    count_v+=1
                    samples2, r_img= sess.run([fake_X_val,real_image], feed_dict={real_test: v_data_batch})

                    samples2 = samples2.transpose(0, 2, 3, 1)
                    batch_images_test = r_img.transpose(0, 2, 3, 1)
                    orin_recon = np.concatenate([batch_images_test, samples2], axis=0)
                    imwrite(immerge(orin_recon, 2, submit_config.batch_size_test), '%s/iter_%08d.png' % (submit_config.run_dir, cur_nimg))

                if cur_tick % network_snapshot_ticks == 0:
                    pkl = os.path.join(submit_config.run_dir, 'network-snapshot-%08d.pkl' % (cur_nimg))
                    misc.save_pkl((M, reM, D, G, C, Gs), pkl)

                cur_tick += 1
                tick_start_nimg = cur_nimg
        misc.save_pkl((M, reM, D, G, C, Gs), os.path.join(submit_config.run_dir, 'network-final.pkl'))
        summary_log.close()

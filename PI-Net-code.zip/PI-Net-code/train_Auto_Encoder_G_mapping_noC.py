import os
import dnnlib
from dnnlib import EasyDict
import config
import copy


os.environ["CUDA_VISIBLE_DEVICES"] = "2"


desc          = 'LIA_AutoEncoder2_G_mapping_noise_4'
train         = EasyDict(run_func_name='training.training_loop_Auto_Encoder_G_mapping_noC.training_loop')

Decoder        = EasyDict(func_name='training.networks_Auto_Encoder_G_mapping_noC.Decoder')
Encoder2       = EasyDict(func_name='training.networks_Auto_Encoder_G_mapping_noC.Encoder_SN')
Classify       = EasyDict(func_name='training.networks_stylegan2.D_stylegan2_C')
E_opt2         = EasyDict(beta1=0.9, beta2=0.99, epsilon=1e-8)
E_loss2        = EasyDict(func_name='training.loss_Auto_Encoder_G_mapping_noC.E2_perceptual_loss', feature_scale=0.00001, D_scale=0.1)
D_loss2        = EasyDict(func_name='training.loss_Auto_Encoder_G_mapping_noC.D_logistic_simplegp', r1_gamma=10.0)

Mapping       = EasyDict(func_name='training.networks_Auto_Encoder_G_mapping_noC_skip.Mapping_noSN_noSkip_noBn')
reMapping     = EasyDict(func_name='training.networks_Auto_Encoder_G_mapping_noC_skip.reMapping')
D             = EasyDict(func_name='training.networks_Auto_Encoder_G_mapping_noC.Discriminator')
M_opt         = EasyDict(beta1=0.9, beta2=0.99, epsilon=1e-8)
reM_opt       = EasyDict(beta1=0.9, beta2=0.99, epsilon=1e-8)
D_opt         = EasyDict(beta1=0.9, beta2=0.99, epsilon=1e-8)
#M_opt         = EasyDict()
#reM_opt       = EasyDict()
#D_opt         = EasyDict()
M_loss        = EasyDict(func_name='training.loss_Auto_Encoder_G_mapping_noC.Mapping_loss', feature_scale=0.00005, D_scale=0.1)
M_lossKl      = EasyDict(func_name='training.loss_Auto_Encoder_G_mapping_noC.Mapping_loss_kl', feature_scale=0.00005, D_scale=0.1)
reM_loss      = EasyDict(func_name='training.loss_Auto_Encoder_G_mapping_noC.reMapping_loss', feature_scale=0.00005, D_scale=0.1)
D_loss        = EasyDict(func_name='training.loss_Auto_Encoder_G_mapping_noC.D_loss')
lr            = EasyDict(learning_rate=0.0001, decay_step=50000, decay_rate=0.8, stair=False)
Data_dir      = EasyDict(data_train='./datasets/ffhq/ffhq_128_train_6w5-r07.tfrecords', data_test='./datasets/ffhq_128_test_5k/ffhq_128_test_5k-r07.tfrecords')
Decoder_pkl   = EasyDict(decoder_pkl='./network-final-ffhq_stylegan1.pkl') #the first stage training results
tf_config     = {'rnd.np_random_seed': 1000}
submit_config = dnnlib.SubmitConfig()

num_gpus = 1; desc += '-1gpu'
# num_gpus = 2; desc += '-2gpu'
# num_gpus = 4; desc += '-4gpu'
#num_gpus = 8; desc += '-8gpu'

image_size = 128; desc += '-128x128'; total_kimg = 1200000000
#image_size = 256; desc += '-256x256'; total_kimg = 14000000

dataset = 'ffhq';           desc += '-ffhq';             train.mirror_augment = True
# dataset = 'lsun-cat';      desc += '-lsun-cat';         train.mirror_augment = False
# dataset = 'lsun-car';      desc += '-lsun-car';         train.mirror_augment = False
# dataset = 'lsun-bedroom';  desc += '-lsun-bedroom';     train.mirror_augment = False

z_dim = 512

minibatch_per_gpu_train = {128: 128, 256: 128}
minibatch_per_gpu_test  = {128: 4, 256: 4}

assert image_size in minibatch_per_gpu_train, 'image size must in minibatch_per_gpu'
batch_size = minibatch_per_gpu_train.get(image_size) * num_gpus
batch_size_test = minibatch_per_gpu_test.get(image_size) * num_gpus
train.max_iters = int(total_kimg/batch_size)

def main():

    kwargs = EasyDict(train)
    kwargs.update(Decoder_args2= Decoder, Encoder_args2=Encoder2, C_args2 = Classify, E_opt_args2=E_opt2, E_loss_args2=E_loss2, D_loss_args2=D_loss2, Mapping_args=Mapping, reMapping_args=reMapping, D_args=D, M_opt_args=M_opt, reM_opt_args=reM_opt, D_opt_args=D_opt, M_loss_args=M_loss, M_kl_loss_args = M_lossKl, reM_loss_args=reM_loss, D_loss_args=D_loss, lr_args=lr)
    kwargs.update(dataset_args=Data_dir, decoder_pkl=Decoder_pkl, tf_config=tf_config)
    kwargs.lr_args.decay_step = train.max_iters // 4
    kwargs.submit_config = copy.deepcopy(submit_config)
    kwargs.submit_config.num_gpus = num_gpus
    kwargs.submit_config.image_size = image_size
    kwargs.submit_config.batch_size = batch_size
    kwargs.submit_config.batch_size_test = batch_size_test
    kwargs.submit_config.z_dim = z_dim
    kwargs.submit_config.run_dir_root = dnnlib.submission.submit.get_template_from_path(config.result_dir)
    kwargs.submit_config.run_dir_ignore += config.run_dir_ignore
    kwargs.submit_config.run_desc = desc
    #kwargs.resume_run_id = '00017' #95 96 98

    dnnlib.submit_run(**kwargs)

#----------------------------------------------------------------------------

if __name__ == "__main__":

    main()

